<?php
/**
 * This file handles the retrieval and serving of news articles
 */
class Registrasikartu_Controller
{
    /**
     * This template variable will hold the 'view' portion of our MVC for this 
     * controller
     */
    public $template = 'news';
    
    /**
     * This is the default function that will be called by router.php
     * 
     * @param array $getVars the GET variables posted to index.php
     */
    public function main(array $getVars)
    {

        //this is a test , and we will be removing it later
        

        // print "We are in registrasi!";
        
<<<<<<< HEAD
        $registrasi_model = New Registrasikartu_Model;
=======
        // $registrasi_model = New Registrasikartu_Model;
>>>>>>> 074a6d28a60b81d26baac84ea89e004d5a2c0613

        // $result = $registrasi_model->check_registered($getVars['uname']);
        // print_r( count($result[0]));

        $view = new View_Model("registrasikartu");
        
    }

    public function daftar(array $getVars){
<<<<<<< HEAD
        $username = $_POST["username"];
        $password = $_POST["password"];
        $nama_lengkap = $_POST["nama_lengkap"];
        $email = $_POST["email"];
=======
>>>>>>> 074a6d28a60b81d26baac84ea89e004d5a2c0613

        foreach ($_POST as $key => $value) {
            echo $value;
        }
<<<<<<< HEAD
=======

        $model = new Registrasikartu_model;

        $sementara = $_POST["expired_date_month"] . " " . $_POST["expired_date_year"];

        $model->register($_POST["no_kartu"],$_POST["nama_pemegang_kartu"], $sementara);
        
>>>>>>> 074a6d28a60b81d26baac84ea89e004d5a2c0613
    }
}