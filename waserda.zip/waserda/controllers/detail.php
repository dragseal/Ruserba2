<?php
/**
 * This file handles the retrieval and serving of news articles
 */
class Detail_Controller
{
    /**
     * This template variable will hold the 'view' portion of our MVC for this 
     * controller
     */
    public $template = 'news';
	
	
    
    /**
     * This is the default function that will be called by router.php
     * 
     * @param array $getVars the GET variables posted to index.php
     */
    public function main(array $getVars)
    {
        //this is a test , and we will be removing it later
        //print "We are in detail barang!";
        
		//$model = new Detail_Model;
		
		$view = new View_Model("detail");

		
    }
	
	public function show(array $getVars){
		$model = new Detail_Model;
		$brg = $_POST["namabarang"];

		$hasil = $model->get_result($brg);
		include 'views/header.php';
		if (isset($hasil)){
			for ($i=0; $i < count($hasil) ; $i++) { 
	            // print_r($hasil[$i]);
	            echo "<br/><br/><br/>";
	            echo "ID barang:" . $hasil[$i]['id_barang'] . "<br/>";
	            echo "Nama :" . $hasil[$i]['nama']. "<br/>";
				echo "Harga :" . $hasil[$i]['harga']. "<br/>";
				echo "Stok :" . $hasil[$i]['stok']. "<br/>";
				echo "Kategori :" . $hasil[$i]['kategori']. "<br/>";
				echo "<img src=\"". $hasil[$i]['img_dir'] . "\">". "<br/>";
			}
		}
		else {
			echo "Nama barang " . $brg . " tidak ada." . "<br/>";
		}
		include 'views/footer.php';
	}
	
}