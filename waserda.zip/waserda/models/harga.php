<?php

class Harga_Model
{
	
	private $db;

    public function __construct(){
        $this->db = new MysqlImproved_Driver;
    }
	
	public function get_result($h1, $h2){
		$this->db->connect();
		//$value = "'%" . $namabarang . "%'";
        //prepare query
        if ($h1 > $h2){
        	$temp = $h1;
			$h1 = $h2;
			$h2 = $temp;
        }
        $this->db->prepare
        (
            "
            SELECT
                *
            FROM
                `data_barang`
            WHERE
            	`harga` BETWEEN " . $h1 . " AND " . $h2 . "
            ;
            "
        );

        //execute query
        $this->db->query();

        
        // $rows[] = $this->db->fetch('array');
        
        while($hasil = $this->db->fetch('array')){
            $rows[] = $hasil;
        }
		if (isset($rows)){
        	return $rows; 
        }
        //return $rows;    
	}
}
