 <?php
/**
 * Define document paths
 */
/*<<<<<<< HEAD
define('SERVER_ROOT' , 'C:/xampp/htdocs/waserda');
=======
define('SERVER_ROOT' , 'C:/xampp/htdocs/waserda');
>>>>>>> 074a6d28a60b81d26baac84ea89e004d5a2c0613  */
define('SERVER_ROOT' , 'C:/xampp/htdocs/waserda');
define('SITE_ROOT' , 'http://localhost');

/**
 * Fetch the router
 */
require_once(SERVER_ROOT . '/controllers/' . 'router.php');

